var menu = document.getElementsByClassName('menu')[0];

menu.onclick = function() {
    menu.classList.toggle('active');
}